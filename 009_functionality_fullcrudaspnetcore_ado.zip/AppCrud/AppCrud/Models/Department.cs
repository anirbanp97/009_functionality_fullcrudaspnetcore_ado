﻿namespace AppCrud.Models
{
    public class Department
    {
        public int IdDepartment { get; set; }
        public string Name { get; set; }
    }
}
